﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;
namespace Oggle
{
    public class GameBoard
    {
        public string[] boardLetters = { "D", "J", "A", "T", "T", "N", "W", "R", "E", "I", "S", "N", "O", "N", "A", "I" };
        public string[] potenialWords = { "ain","aine","ains","ais","ait","and","ane","anent","ani","anion","anions","anis","anoint","ansa","ant","ante","anti","antis","arna","arnas","ars","arsine","arsino","art","awn","awns","eina","end","ens","entia","eon","eonian","eons","etna","inane","ins","insane","insanie","inwind","inwit","ion","ions","isit","isna","jane","jar","jars","jaw","jaws","nain","nan","nane","nans","nas","nasion","nat","naw","neon","neons","net","nie","nine","ninja","nis","nisi","nit","nite","noint","oint","one","onie","ons","raj","ran","rand","rani","ranine","ranis","rant","rat","raw","rawin","rawins","rawn","rawns","raws","sai","sain","saine","saint","san","sane","sien","sient","sin","sind","sine","sit","site","snar","snaw","snit","swan","swart","swat","swine","taj","tan","tane","tans","tanti","tar","tarn","tarns","tars","tarsi","tarsia","taw","tawie","taws","teind","ten","tend","tenia","tenias","tens","tension","tie","tin","tind","tine","tins","tis","tisane","trans","transit","trant","twa","twin","twine","twins","twit","twite","wan","wand","wane","wanion","wanions","wans","want","war","warn","warns","wars","wart","wat","win","wind","wine","wino","wins","wis","wit","wite"};

    }
}
