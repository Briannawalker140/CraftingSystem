﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oggle
{
    public class Player
    {
        public List<string> guessedWords = new List<string>();
        public int Score = 0;
    }
}
