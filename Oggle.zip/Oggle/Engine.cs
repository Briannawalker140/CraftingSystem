﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oggle
{
    public class Engine
    {
        private Player player = new Player();
        private GameBoard board = new GameBoard();

        public void SetUp()
        {
            //TODO: add ability to read external letters and pontenial words and add them to the board
            //print the letters of the board to the console
            Console.Title = "Oggole";
            Console.WriteLine("Welcome and instructions");
            PrintBoard();
            Runtime();
        }

        private void Runtime()
        {
            Console.Clear();
            //insert timer code here
            //limit # of guesses
            Console.WriteLine("Word: ");
            string input = Console.ReadLine().ToLower();
            if (input != "x")
            {
                //is it a vaild word
                //has the player already guessed that word
                //vaild and it hasn't been guessed - increase score 
                if (isVaild(input))
                {
                    if (!hasGuessed(input))
                    {
                        player.guessedWords.Add(input);
                        player.Score += input.Length;
                        
                    }
                    else
                    {
                        Console.WriteLine("Already guessed" + input);
                    }
                    Console.WriteLine(input + "added");
                }
                Console.WriteLine("your score:" + player.Score + "press any key to continue");
                Console.ReadKey();
                Console.Clear();
                PrintBoard();
                Runtime();
                
            }
        }

        private bool hasGuessed(string word)
        {
            foreach (string s in player.guessedWords)
            {
                if (s == word)
                {
                    return true;
                }
                return false;
            }
        }

        private bool isVaild(string word)
        {
            foreach (string s in board.potenialWords)
            {
                if (s == word)
                {
                    return true;
                }
                return false;
            }
        }
        private void PrintBoard()
        {
            //4 x 4 

            int Index = 0;
            for (int i = 0; i<4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Index = 4+i+j;
                    Console.Write($"  {board.boardLetters[Index]}   ");
                }
                Console.WriteLine();
                Console.WriteLine();
            }
        }
    }
}
