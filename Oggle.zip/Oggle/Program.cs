﻿namespace Oggle
{
    internal class Program
    {
        
    }
}
