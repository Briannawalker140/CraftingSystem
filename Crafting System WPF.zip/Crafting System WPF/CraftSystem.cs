﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crafting_System_WPF
{
    public class CraftSystem
    {
        public Player player = new Player();
    }
}
