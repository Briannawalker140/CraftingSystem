﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crafting_System_WPF
{
    public class Player
    {
        public List<Item> Inventory = new List<Item>();
        public string Name = "Unknown Player";
        public Player()
        {
            Inventory.Add(
                new Item()
                { 
                    Name = "map", 
                    Description = "older map" 
                });
            Inventory.Add(
                new Item() 
                { 
                    Name = "coin", 
                    Description = "is valuable and can be used for something" 
                });
        }
        public string GetInventoryItemList()
        {
            string output = "Inventory Items: \n";
            foreach (Item item in Inventory)
            {
                output += $"{item.Name} ({item.Description})";
            }
            return output;
        }
    }
}
