﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crafting_System_WPF
{
    public class Item
    {
        public string Name;
        public string Description;  
    }
}
