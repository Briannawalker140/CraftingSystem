﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Crafting_System_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int imageNumber = 0;
        CraftSystem craftSystem = new CraftSystem();
        Animal[] Animals = { 
            new Animal() {
                Name = "dog", ImagePath = "dog.bmp"
            },
            new Animal() {
                Name = "cat", ImagePath = "cat.bmp"
            },
            new Animal() {
                Name = "snake", ImagePath = "snake.bmp"
            }
        };
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            Title.Content = $"{craftSystem.player.Name} Player's Inventory";
            Information.Text = craftSystem.player.GetInventoryItemList();
            Portrait.Source = new BitmapImage(new Uri(Animals[imageNumber].ImagePath, UriKind.Relative));
        }

        private void NextNavigation_Click(object sender, RoutedEventArgs e)
        {
            //increment image number 
            imageNumber++;
            //check the range
            if (imageNumber > (Animals.Length-1))
            {
                imageNumber = -1;
                NextNavigation.Content = "Restart";
            }
            else
            {
                NextNavigation.Content = "Next";
                Portrait.Source = new BitmapImage(new Uri(Animals[imageNumber].ImagePath, UriKind.Relative));
            }
            //set the image to the correct path
        }
    }
}